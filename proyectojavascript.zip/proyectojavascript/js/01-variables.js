let producto = "nombre del producto";
let disponible;

disponible = true;

let camiseta = "red",
    pantalon = "black",
    zapatos = 38;      // todas tienen que ser del mismo tipo para simplificar el codigo
    console.log("COMENTARIO Camiseta:",camiseta);

    // let 1numero1 = "black" ERROR nombrar con numero, consola ubica el error y te da su ubicacion

const constante= "valorConstante";
console.log("constprueba"),constante;

